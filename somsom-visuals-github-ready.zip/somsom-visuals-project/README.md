# Somsom Visuals 1.0.0

Fabric client mod project targeting Minecraft 1.21.11. This is a reconstructed starter HUD project, not a verified build. It includes a player/server/FPS header, online-player list (not server-specific staff detection), potion effects and timers, a basic held-item cooldown status, and player coordinates. No KillAura or Speed modules are included.

## Build automatically on GitHub

This project includes `.github/workflows/build.yml`. Upload the contents of this folder to a GitHub repository. The workflow builds on every push to `main`; it can also be started manually from the **Actions** tab using **Build Somsom Visuals**. When complete, download the `somsom-visuals-1.0.0` artifact from the workflow run.

Requires Java 21 and internet access for Gradle to download Minecraft/Fabric dependencies.
