package ru.somsom.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class SomsomVisuals implements ClientModInitializer {
    private static final int PANEL = 0xB8171728;
    private static final int ACCENT = 0xFF9B8CFF;
    private static final int TEXT = 0xFFF2F0FF;
    private static final int MUTED = 0xFFB9B4D0;

    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(Identifier.of("somsomvisuals", "main_hud"),
                (context, tickCounter) -> render(context));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        int x = 12, y = 12;
        String server = mc.getCurrentServerEntry() == null ? "Singleplayer" : mc.getCurrentServerEntry().address;
        String top = mc.player.getName().getString() + "   •   " + server + "   •   " + mc.getCurrentFps() + " fps";
        panel(ctx, x, y, Math.min(mc.getWindow().getScaledWidth() - 24, mc.textRenderer.getWidth(top) + 24), 25);
        ctx.drawTextWithShadow(mc.textRenderer, top, x + 10, y + 8, TEXT);

        int leftX = x, rightX = Math.min(x + 230, mc.getWindow().getScaledWidth() - 150);
        int rowY = y + 34;

        // StaffList panel: displays the current online player list; staff roles need server-specific names.
        List<String> players = new ArrayList<>();
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().getPlayerList().stream().limit(5)
                    .forEach(info -> players.add(info.getProfile().getName()));
        }
        int staffH = 25 + Math.max(1, players.size()) * 13;
        panel(ctx, leftX, rowY, 190, staffH);
        heading(ctx, "StaffList", leftX + 10, rowY + 8);
        if (players.isEmpty()) line(ctx, "No players", leftX + 10, rowY + 25);
        else for (int i = 0; i < players.size(); i++) line(ctx, players.get(i), leftX + 10, rowY + 25 + i * 13);

        // Potions panel
        int potY = rowY + staffH + 10;
        List<StatusEffectInstance> effects = new ArrayList<>(mc.player.getStatusEffects());
        panel(ctx, leftX, potY, 190, 27 + Math.max(1, effects.size()) * 14);
        heading(ctx, "Potions", leftX + 10, potY + 8);
        if (effects.isEmpty()) line(ctx, "No active effects", leftX + 10, potY + 25);
        else for (int i = 0; i < effects.size(); i++) {
            StatusEffectInstance e = effects.get(i);
            String name = e.getEffectType().value().getName().getString();
            line(ctx, name + "  " + formatTicks(e.getDuration()), leftX + 10, potY + 25 + i * 14);
        }

        // Cooldown panel (shows held item cooldown when available)
        int coolY = rowY;
        panel(ctx, rightX, coolY, 180, 54);
        heading(ctx, "Cooldown", rightX + 10, coolY + 8);
        line(ctx, "Item cooldown: " + (mc.player.getItemCooldownManager().isCoolingDown(mc.player.getMainHandStack()) ? "active" : "ready"), rightX + 10, coolY + 28);

        // GPS / coordinates panel
        int gpsY = coolY + 64;
        panel(ctx, rightX, gpsY, 180, 42);
        heading(ctx, "GPS", rightX + 10, gpsY + 7);
        String coords = String.format("%.0f, %.0f, %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        line(ctx, coords, rightX + 10, gpsY + 24);
    }

    private static void panel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, PANEL);
        ctx.fill(x, y, x + 3, y + h, ACCENT);
    }

    private static void heading(DrawContext ctx, String text, int x, int y) {
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, x, y, ACCENT);
    }

    private static void line(DrawContext ctx, String text, int x, int y) {
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, x, y, TEXT);
    }

    private static String formatTicks(int ticks) {
        int seconds = Math.max(0, ticks) / 20;
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }
}
